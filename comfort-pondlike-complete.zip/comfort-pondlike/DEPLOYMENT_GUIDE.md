# Comfort & Pondlike - Deployment Guide

## Overview
This guide provides step-by-step instructions for deploying the Comfort & Pondlike website and admin panel to Vercel, including environment variable configuration for the chatbot API.

## Project Structure
```
comfort-pondlike/
├── index.html              # Main website
├── css/
│   └── styles.css          # Website styles
├── js/
│   └── main.js             # Website JavaScript
├── images/                 # Website assets
├── admin/                  # Admin panel
│   ├── server.js           # Node.js backend
│   ├── package.json        # Dependencies
│   └── public/
│       └── admin.html      # Admin interface
├── seo-generator.py        # SEO content generator
├── wordpress-shortcode.php # WordPress integration
└── DEPLOYMENT_GUIDE.md     # This file
```

## Prerequisites
- Vercel account (free tier available)
- Git repository (GitHub, GitLab, or Bitbucket)
- Node.js 18+ for local development
- Dialogflow account for chatbot integration

## Step 1: Prepare Your Repository

### 1.1 Initialize Git Repository
```bash
cd comfort-pondlike
git init
git add .
git commit -m "Initial commit: Comfort & Pondlike website"
```

### 1.2 Push to GitHub
```bash
# Create a new repository on GitHub first
git remote add origin https://github.com/yourusername/comfort-pondlike.git
git branch -M main
git push -u origin main
```

## Step 2: Configure Environment Variables

### 2.1 Create Environment Files
Create a `.env` file in the admin directory:
```bash
# Admin Panel Environment Variables
JWT_SECRET=your-super-secret-jwt-key-here
NODE_ENV=production
PORT=3001

# Dialogflow Configuration
GOOGLE_PROJECT_ID=your-dialogflow-project-id
GOOGLE_CLIENT_EMAIL=your-service-account-email
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYour private key here\n-----END PRIVATE KEY-----\n"

# Database Configuration (if using external database)
DATABASE_URL=your-database-connection-string

# Email Configuration (for notifications)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
```

### 2.2 Update .gitignore
Create a `.gitignore` file:
```
node_modules/
.env
.env.local
.env.production
.vercel
uploads/
*.log
.DS_Store
```

## Step 3: Configure Vercel Deployment

### 3.1 Create vercel.json
Create a `vercel.json` file in the root directory:
```json
{
  "version": 2,
  "builds": [
    {
      "src": "index.html",
      "use": "@vercel/static"
    },
    {
      "src": "admin/server.js",
      "use": "@vercel/node"
    }
  ],
  "routes": [
    {
      "src": "/admin/(.*)",
      "dest": "/admin/server.js"
    },
    {
      "src": "/api/(.*)",
      "dest": "/admin/server.js"
    },
    {
      "src": "/(.*)",
      "dest": "/$1"
    }
  ],
  "env": {
    "NODE_ENV": "production"
  },
  "functions": {
    "admin/server.js": {
      "maxDuration": 30
    }
  }
}
```

### 3.2 Update package.json for Admin
Ensure your `admin/package.json` includes the start script:
```json
{
  "name": "comfort-pondlike-admin",
  "version": "1.0.0",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "multer": "^1.4.5",
    "cors": "^2.8.5",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "express-session": "^1.17.3"
  }
}
```

## Step 4: Deploy to Vercel

### 4.1 Install Vercel CLI
```bash
npm install -g vercel
```

### 4.2 Login to Vercel
```bash
vercel login
```

### 4.3 Deploy the Project
```bash
# From the project root directory
vercel

# Follow the prompts:
# ? Set up and deploy "comfort-pondlike"? [Y/n] y
# ? Which scope do you want to deploy to? [Your Account]
# ? Link to existing project? [y/N] n
# ? What's your project's name? comfort-pondlike
# ? In which directory is your code located? ./
```

### 4.4 Configure Environment Variables in Vercel Dashboard
1. Go to your Vercel dashboard
2. Select your project
3. Go to Settings → Environment Variables
4. Add the following variables:

| Name | Value | Environment |
|------|-------|-------------|
| JWT_SECRET | your-super-secret-jwt-key-here | Production |
| GOOGLE_PROJECT_ID | your-dialogflow-project-id | Production |
| GOOGLE_CLIENT_EMAIL | your-service-account-email | Production |
| GOOGLE_PRIVATE_KEY | "-----BEGIN PRIVATE KEY-----..." | Production |
| NODE_ENV | production | Production |

## Step 5: Configure Dialogflow Integration

### 5.1 Create Dialogflow Project
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable the Dialogflow API
4. Create a service account with Dialogflow API Admin role
5. Download the service account key JSON file

### 5.2 Extract Credentials
From the downloaded JSON file, extract:
- `project_id` → GOOGLE_PROJECT_ID
- `client_email` → GOOGLE_CLIENT_EMAIL  
- `private_key` → GOOGLE_PRIVATE_KEY

### 5.3 Update Chat Widget
Update the chat widget in `js/main.js` to use your Dialogflow project:
```javascript
// Update the Dialogflow configuration
const dialogflowConfig = {
    projectId: 'your-dialogflow-project-id',
    sessionId: 'user-session-' + Date.now(),
    languageCode: 'en-US'
};
```

## Step 6: Custom Domain Setup (Optional)

### 6.1 Add Custom Domain
1. In Vercel dashboard, go to Settings → Domains
2. Add your custom domain (e.g., comfortpondlike.com)
3. Configure DNS records as instructed by Vercel

### 6.2 SSL Certificate
Vercel automatically provides SSL certificates for all domains.

## Step 7: Performance Optimization

### 7.1 Enable Compression
Add to `vercel.json`:
```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ]
}
```

### 7.2 Image Optimization
Use Vercel's image optimization by updating image URLs:
```html
<!-- Before -->
<img src="/images/product1.jpg" alt="Product">

<!-- After -->
<img src="/_next/image?url=/images/product1.jpg&w=640&q=75" alt="Product">
```

## Step 8: Monitoring and Analytics

### 8.1 Vercel Analytics
Enable Vercel Analytics in your dashboard for performance monitoring.

### 8.2 Error Tracking
Add error tracking to your admin panel:
```javascript
// Add to server.js
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    process.exit(1);
});
```

## Step 9: Testing Deployment

### 9.1 Test Website
1. Visit your deployed URL
2. Test all sliders and animations
3. Verify responsive design on mobile
4. Test speech synthesis functionality
5. Check chat widget integration

### 9.2 Test Admin Panel
1. Visit `/admin` endpoint
2. Login with credentials (admin/password)
3. Test social media icon management
4. Test slider content upload
5. Verify file upload functionality

## Step 10: Maintenance and Updates

### 10.1 Continuous Deployment
Vercel automatically deploys when you push to your main branch.

### 10.2 Environment Management
- Use different branches for staging/production
- Test changes in preview deployments
- Monitor performance metrics

### 10.3 Backup Strategy
- Regular database backups (if using external DB)
- Version control for all code changes
- Document configuration changes

## Troubleshooting

### Common Issues

#### 1. Build Failures
```bash
# Check build logs in Vercel dashboard
# Common fixes:
- Ensure all dependencies are in package.json
- Check Node.js version compatibility
- Verify file paths are correct
```

#### 2. Environment Variables Not Working
```bash
# Ensure variables are set in Vercel dashboard
# Check variable names match exactly
# Restart deployment after adding variables
```

#### 3. Admin Panel 404 Errors
```bash
# Verify vercel.json routing configuration
# Check server.js file location
# Ensure admin build is included
```

#### 4. Dialogflow Integration Issues
```bash
# Verify service account permissions
# Check project ID matches
# Ensure private key format is correct
```

### Support Resources
- [Vercel Documentation](https://vercel.com/docs)
- [Dialogflow Documentation](https://cloud.google.com/dialogflow/docs)
- [Node.js Deployment Guide](https://vercel.com/docs/functions/serverless-functions/runtimes/node-js)

## Security Considerations

### 1. Environment Variables
- Never commit sensitive data to Git
- Use strong JWT secrets
- Rotate API keys regularly

### 2. Admin Panel Security
- Change default admin credentials
- Implement rate limiting
- Use HTTPS only
- Regular security updates

### 3. File Upload Security
- Validate file types
- Limit file sizes
- Scan for malware
- Use secure storage

## Performance Monitoring

### Key Metrics to Track
- Page load times
- Core Web Vitals
- API response times
- Error rates
- User engagement

### Tools
- Vercel Analytics
- Google PageSpeed Insights
- GTmetrix
- Google Search Console

## Conclusion

Following this guide will successfully deploy your Comfort & Pondlike website to Vercel with full functionality including the admin panel and chatbot integration. Remember to test thoroughly and monitor performance after deployment.

For additional support or custom modifications, refer to the project documentation or contact the development team.

